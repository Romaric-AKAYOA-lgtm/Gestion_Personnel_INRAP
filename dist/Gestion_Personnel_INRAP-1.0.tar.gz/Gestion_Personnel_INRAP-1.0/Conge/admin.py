from django.contrib import admin
# Register your models here.
from .models import  Conge
admin.site.register(Conge)
