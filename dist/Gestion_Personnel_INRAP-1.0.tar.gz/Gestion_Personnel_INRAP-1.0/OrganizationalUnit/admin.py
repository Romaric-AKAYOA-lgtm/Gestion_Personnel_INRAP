from django.contrib import admin
from .models import OrganizationalUnit
# Register your models here.
admin.site.register(OrganizationalUnit)