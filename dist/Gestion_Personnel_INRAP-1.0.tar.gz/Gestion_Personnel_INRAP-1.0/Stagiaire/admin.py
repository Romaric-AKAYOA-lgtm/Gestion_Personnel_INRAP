from django.contrib import admin

# Register your models here.
from .models import  Stagiaire
admin.site.register(Stagiaire)
