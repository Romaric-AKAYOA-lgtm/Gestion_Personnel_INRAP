from django.apps import AppConfig


class SpecialiteConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'specialite'
