from django.apps import AppConfig


class UniteConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'unite'
